//
//  File 2.swift
//  OneDiary
//
//  Created on 2025/1/25.
//

import SwiftUI

struct DiaryView: View {
    @State private var diaryContent: String = ""
    @State private var aiInput: String = ""
    @State private var aiResponse: String = ""
    @State private var isAIChatMode: Bool = false
    @Binding var diaryEntries: [DiaryEntry]

    
    var incrementProgress: () -> Void
    
    var body: some View {
        ZStack {
            // background
            Color(red: 0.973, green: 0.965, blue: 0.901)

                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                
                Text(isAIChatMode ? "❓Question and Answer" : "📖 Daily Journal")
                    .font(.title2.weight(.semibold))
                    .foregroundColor(.primary)
                    .transition(.opacity)
                
                
                Spacer()
                
                
                Group {
                    if isAIChatMode {
                        AIChatView
                    } else {
                        JournalView
                    }
                }
                .frame(maxWidth: 600) //
                .padding(.horizontal)
                
                Spacer()
                
                ModeSwitchButton
            }
            .padding(.vertical)
        }
    }

    // AI view
    private var AIChatView: some View {
        VStack(spacing: 16) {
            
            Text("What can I help with?(waiting for 10-15s)")
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            HStack(alignment: .bottom, spacing: 12) {
                
                
                
                CustomTextField(
                    text: $aiInput,
                    placeholder: "Ask me anything...",
                    systemImage: "sparkles"
                )
                
                SendButton(action: sendToOpenAIAPI)
            }
            
            
            if !aiResponse.isEmpty {
                ResponseView(text: aiResponse)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
    }

    // Journal View
    private var JournalView: some View {
        VStack(spacing: 16) {
            Text(moodPrompt)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            
            HStack(alignment: .bottom, spacing: 12) {
                CustomTextField(
                    text: $diaryContent,
                    placeholder: "What happened today?",
                    systemImage: "text.bubble"
                )
                
                SendButton(action: saveDiaryEntry)
            }
        }
    }

    
    private struct CustomTextField: View {
        @Binding var text: String
        let placeholder: String
        let systemImage: String
        
        var body: some View {
            HStack {
                TextField(placeholder, text: $text)
                    .textFieldStyle(.plain)
                    .accentColor(.blue)
                
                Image(systemName: systemImage)
                    .foregroundColor(.secondary)
            }
            .padding(12)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color(.secondarySystemBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color(.separator), lineWidth: 0.5)
            )
        }
    }

    //
    private struct ResponseView: View {
        let text: String
        
        var body: some View {
            ScrollView {
                Text(text)
                    .font(.body)
                    .multilineTextAlignment(.leading)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
            }
            .frame(maxHeight: 300)
            .background(
                RoundedRectangle(cornerRadius: 16)
                    .fill(Color(.tertiarySystemBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .stroke(Color(.separator), lineWidth: 0.5)
            )
        }
    }

    //
    private struct SendButton: View {
        let action: () -> Void
        
        var body: some View {
            Button(action: action) {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 32))
                    .symbolRenderingMode(.hierarchical)
                    .foregroundColor(.blue)
                    .padding(4)
                    .contentShape(Circle())
            }
            .buttonStyle(.plain)
        }
    }

    //
    private var ModeSwitchButton: some View {
        VStack(spacing: 8) {
            Text("Switch Mode")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Button {
                withAnimation(.spring()) {
                    isAIChatMode.toggle()
                    aiInput = ""
                    aiResponse = ""
                }
            } label: {
                Image(systemName: isAIChatMode ? "book" : "brain.head.profile")
                    .font(.title3.weight(.medium))
                    .foregroundColor(.primary)
                    .padding(12)
//                    .background(
//                        Circle()
//                            .fill(Color(.secondarySystemBackground))
//                    )
            }
            .buttonStyle(.plain)
        }
    }
    
    //  UserDefaults
    private func saveDiaryEntries() {
        if let encoded = try? JSONEncoder().encode(diaryEntries) {
            UserDefaults.standard.set(encoded, forKey: "diaryEntries")
        }
    }
    
    //
    private var moodPrompt: String {
        let recentMoods = diaryEntries.suffix(3).compactMap { $0.mood }
        
        if recentMoods.count >= 3 && recentMoods.suffix(3).allSatisfy({ $0 == "🤔" }) {
            return "Be happy cuz we are under the sun ."
        }
        
        if recentMoods.count >= 2 && recentMoods.suffix(2).allSatisfy({ $0 == "😢" }) {
            return "Keep your chin up !"
        }
        
        if recentMoods.count >= 2 && recentMoods.suffix(2).allSatisfy({ $0 == "😡" }) {
            return "Calm down to make a closure ."
        }
        
        return "How are you feeling today?"
    }
    
    //  OpenAI API
    private func sendToOpenAIAPI() {
        guard !aiInput.isEmpty else { return }
        
        let apiKey = "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"
        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let requestBody: [String: Any] = [
            "model": "gpt-4o-mini",
            "messages": [
                [
                    "role": "user",
                    "content": aiInput
                ]
            ],
            "temperature": 0.7,
            "max_tokens": 1000
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: requestBody, options: [])
            if let bodyString = String(data: request.httpBody!, encoding: .utf8) {
                print("Request body: \(bodyString)")
            }
        } catch {
            print("Failed to encode request body: \(error)")
            return
        }
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("API request failed: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    aiResponse = "Failed to connect to AI"
                }
                return
            }
            
            if let httpResponse = response as? HTTPURLResponse {
                print("HTTP Status Code: \(httpResponse.statusCode)")
            }
            
            guard let data = data else {
                print("No data received from API")
                DispatchQueue.main.async {
                    aiResponse = "No response from AI"
                }
                return
            }
            
            if let jsonString = String(data: data, encoding: .utf8) {
                print("API response: \(jsonString)")
            }
            
            do {
                if let json = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let choices = json["choices"] as? [[String: Any]],
                   let firstChoice = choices.first,
                   let message = firstChoice["message"] as? [String: Any],
                   let text = message["content"] as? String {
                    DispatchQueue.main.async {
                        aiResponse = text
                    }
                } else {
                    print("Failed to parse 'choices' or 'message' from response")
                    DispatchQueue.main.async {
                        aiResponse = "Failed to parse AI response"
                    }
                }
            } catch {
                print("Failed to decode API response: \(error)")
                DispatchQueue.main.async {
                    aiResponse = "Failed to decode AI response"
                }
            }
        }.resume()
    }

    
    
    private func saveDiaryEntry() {
        guard !diaryContent.isEmpty else { return }
        
        let newEntry = DiaryEntry(id: UUID(), date: Date(), content: diaryContent)
        diaryEntries.append(newEntry)
        saveDiaryEntries() // save to UserDefaults
        incrementProgress() // progress
        diaryContent = ""
    }

    

    
}
