//
//  File 5.swift
//  
//
//  Created on 2025/1/25.
//

import SwiftUI
import PhotosUI

private let QUOTABLE_API = "https://api.forismatic.com/api/1.0/?method=getQuote&format=json&lang=en"
private let CACHE_KEY = "cachedQuotes"


struct DiaryDetailView: View {
    @Binding var entry: DiaryEntry
    @Binding var diaryEntries: [DiaryEntry]
    
    @State private var selectedImages: [UIImage] = []
    @State private var isPhotoPickerPresented = false
    @State private var isMoodPickerPresented = false
    @State private var isActive: Bool = true
    @State private var isQuoteCardPresented = false
    @State private var selectedQuote: Quote?
    @State private var isQuoteLoading = false
    @State private var apiError: String?
    
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        
        VStack(alignment: .leading, spacing: 16) {
            
            Text(entry.date, style: .date)
                .font(.body)
                .foregroundColor(.gray)

            // content
            ScrollView {
                Text(entry.content)
                    .font(.title2)
                    .lineLimit(nil)
                    .padding()
                    .background(Color(.systemGray6))
                    .cornerRadius(12)
                 
            }
            
            // photos
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 16) {
                    ForEach(selectedImages, id: \.self) { image in
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 120)
                            .cornerRadius(8)
                            .shadow(radius: 5)
                            .border(Color.gray.opacity(0.3), width: 1)
                    }
                }
                .padding(.vertical, 8)
            }
            
            // button
            VStack(spacing: 20) {
                HStack {
                    // 1
                    Button(action: {
                        isPhotoPickerPresented = true
                    }) {
                        buttonContent(icon: "photo", color: .blue)
                    }
                    
                    // 2
                    Button(action: {
                        isMoodPickerPresented = true
                    }) {
                        buttonContent(text: entry.mood ?? "😐", color: .orange)
                    }
                    .actionSheet(isPresented: $isMoodPickerPresented) {
                        ActionSheet(
                            title: Text("How was your day?"),
                            buttons: ["😊", "😢", "😡", "😍", "😎", "🤔"].map { mood in
                                .default(Text(mood)) {
                                    entry.mood = mood
                                    saveDiaryEntries()
                                }
                            } + [.cancel()]
                        )
                    }

                    // 3
                    Button(action: fetchDailyQuote) {
                        buttonContent(icon: "quote.bubble", color: .green)
                    }
                    .disabled(isQuoteLoading)
//                    .padding(.top, 100)
                }
                .padding(.horizontal)

                // error
                .alert("API Error", isPresented: .constant(apiError != nil)) {
                    Button("OK") { apiError = nil }
                } message: {
                    Text(apiError ?? "")
                }
                
                
                .sheet(isPresented: $isQuoteCardPresented) {
                    Group {
                        if isQuoteLoading {
                            ProgressView("Fetching wisdom...")
                                .progressViewStyle(CircularProgressViewStyle())
                        } else if let quote = selectedQuote {
                            QuoteCardView(quote: quote)
                        }
                    }
                    .padding()
                }
            }
            
            Spacer()
        }
        .padding()
//        .background(Color(UIColor.systemGroupedBackground))
        .sheet(isPresented: $isPhotoPickerPresented) {
            PhotoPicker(selectedImages: $selectedImages)
        }
        .onAppear {
            isActive = true
            selectedImages = entry.photoPaths.compactMap { loadImageFromDocumentsDirectory(fileName: $0) }
        }
        .onDisappear {
            isActive = false
        }
        .onChange(of: selectedImages) { newImages in
            guard isActive, diaryEntries.contains(where: { $0.id == entry.id }) else { return }
            entry.photoPaths = newImages.compactMap { saveImageToDocumentsDirectory(image: $0) }
            saveDiaryEntries()
        }
    }

    
    private func buttonContent(icon: String, color: Color) -> some View {
        HStack {
            Image(systemName: icon)
        }
        .padding()
        .frame(width: 100)
        .background(LinearGradient(gradient: Gradient(colors: [color.opacity(0.8), color]), startPoint: .top, endPoint: .bottom))
        .foregroundColor(.white)
        .cornerRadius(8)
        .shadow(radius: 5)
    }

    private func buttonContent(text: String, color: Color) -> some View {
        HStack {
            Text(text)
                .font(.body)
                .fontWeight(.bold)
        }
        .padding()
        .frame(width: 100)
        .background(LinearGradient(gradient: Gradient(colors: [color.opacity(0.8), color]), startPoint: .top, endPoint: .bottom))
        .foregroundColor(.white)
        .cornerRadius(8)
        .shadow(radius: 5)
    }


    // quote api
    private func fetchDailyQuote() {
        isQuoteLoading = true
        isQuoteCardPresented = true
        
        _Concurrency.Task {
            do {
                guard let url = URL(string: "https://api.forismatic.com/api/1.0/?method=getQuote&format=json&lang=en") else {
                    throw NSError(domain: "Invalid URL", code: 0)
                }
                
                let (data, _) = try await URLSession.shared.data(from: url)
                
                // JSONDecoder
                let decoder = JSONDecoder()
                let newQuote = try decoder.decode(Quote.self, from: data)
                
                // UI
                await MainActor.run {
                    selectedQuote = newQuote
                    isQuoteLoading = false
                }
            } catch {
                // error
                await MainActor.run {
                    apiError = error.localizedDescription
                    isQuoteLoading = false
                }
            }
        }
    }
        
        // cachequote
        private func cacheQuote(_ quote: Quote) {
            let encoder = JSONEncoder()
            if let encoded = try? encoder.encode(quote) {
                UserDefaults.standard.set(encoded, forKey: CACHE_KEY)
            }
        }
        
        private func loadCachedQuote() -> Quote? {
            guard let data = UserDefaults.standard.data(forKey: CACHE_KEY) else { return nil }
            return try? JSONDecoder().decode(Quote.self, from: data)
        }
    

    // delete
    private func deleteEntry() {
        if let index = diaryEntries.firstIndex(where: { $0.id == entry.id }) {
            diaryEntries.remove(at: index)
            saveDiaryEntries()
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            presentationMode.wrappedValue.dismiss()
        }
    }

    // UserDefaults
    private func saveDiaryEntries() {
        do {
            print("Current mood: \(entry.mood ?? "nil")")
            let encoded = try JSONEncoder().encode(diaryEntries)
            UserDefaults.standard.set(encoded, forKey: "diaryEntries")
            print("Saved diary entries: \(diaryEntries)")
            if let jsonString = String(data: encoded, encoding: .utf8) {
                print("Encoded data: \(jsonString)")
            }
        } catch {
            print("Failed to encode diary entries: \(error)")
        }
    }

    
    private func loadImageFromDocumentsDirectory(fileName: String) -> UIImage? {
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        if let imageData = try? Data(contentsOf: fileURL) {
            return UIImage(data: imageData)
        }
        return nil
    }

    
    private func saveImageToDocumentsDirectory(image: UIImage) -> String? {
        guard let data = image.jpegData(compressionQuality: 1.0) else { return nil }
        let fileName = UUID().uuidString + ".jpg"
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent(fileName)
        do {
            try data.write(to: fileURL)
            return fileName
        } catch {
            print("Failed to save image: \(error)")
            return nil
        }
    }
}
// MARK: - PhotoPicker

struct PhotoPicker: UIViewControllerRepresentable {
    @Binding var selectedImages: [UIImage]
    
    func makeUIViewController(context: Context) -> PHPickerViewController {
        var configuration = PHPickerConfiguration()
        configuration.filter = .images
        configuration.selectionLimit = 0 // limit
        
        let picker = PHPickerViewController(configuration: configuration)
        picker.delegate = context.coordinator
        return picker
    }
    
    func updateUIViewController(_ uiViewController: PHPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, PHPickerViewControllerDelegate {
        let parent: PhotoPicker
        
        init(_ parent: PhotoPicker) {
            self.parent = parent
        }
        
        func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
            picker.dismiss(animated: true)
            
            
            for result in results {
                result.itemProvider.loadObject(ofClass: UIImage.self) { (object, error) in
                    if let image = object as? UIImage {
                        DispatchQueue.main.async {
                            self.parent.selectedImages.append(image)
                        }
                    }
                }
            }
        }
    }
}


