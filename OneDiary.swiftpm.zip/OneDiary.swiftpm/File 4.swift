//
//  File 4.swift
//  
//
//  Created  on 2025/1/25.
//

import SwiftUI
import NaturalLanguage

struct DiaryListView: View {
    @Binding var diaryEntries: [DiaryEntry]
    
    var body: some View {
        
        NavigationView {
            
            List {
                
                ForEach(groupedEntries.keys.sorted(by: >), id: \.self) { date in
                    Section(header: Text(date, style: .date)
                                .font(.headline)
                                .foregroundColor(.accentColor)
                                .padding(.top, 10)
                                .padding(.bottom, 5)) {
                        ForEach(groupedEntries[date] ?? []) { entry in
                            NavigationLink(destination: DiaryDetailView(entry: binding(for: entry), diaryEntries: $diaryEntries)) {
                                HStack {
                                    
                                    Text(extractKeywords(from: entry.content, count: 2))
                                        .font(.body)
                                        .lineLimit(1)
                                        .foregroundColor(.primary)
                                        .padding(.vertical, 6)
                                        .padding(.horizontal, 10)
                                        .background(RoundedRectangle(cornerRadius: 8).fill(Color.white)/*.shadow(radius: 5)*/)

                                    Spacer()

                                    
                                    Text(entry.mood ?? "😐")
                                        .font(.body)
                                        .foregroundColor(.secondary)
                                        .padding(.vertical, 6)
                                        .padding(.horizontal, 10)
                                        .background(RoundedRectangle(cornerRadius: 8).fill(Color.white).shadow(radius: 2))
                                }
                                .padding(.vertical, 8)
                                .padding(.horizontal, 10)
                                .background(RoundedRectangle(cornerRadius: 12).fill(Color.white)/*.shadow(radius: 4)*/)
                            }
                        }
                        .onDelete { offsets in
                            deleteEntries(at: offsets, for: date)
                        }
                    }
                }
            }
            .listStyle(PlainListStyle())
            .navigationTitle("My Diary")
            .onAppear {
                loadDiaryEntries()
            }
        }
        .background(Color(UIColor.systemGroupedBackground))
    }


 
    private var groupedEntries: [Date: [DiaryEntry]] {
        Dictionary(grouping: diaryEntries) { entry in
            
            Calendar.current.startOfDay(for: entry.date)
        }
    }

 
    private func deleteEntries(at offsets: IndexSet, for date: Date) {
        if let entries = groupedEntries[date] {
            for offset in offsets {
                if let index = diaryEntries.firstIndex(where: { $0.id == entries[offset].id }) {
                    diaryEntries.remove(at: index)
                }
            }
            saveDiaryEntries()
        }
    }


    private func saveDiaryEntries() {
        if let encoded = try? JSONEncoder().encode(diaryEntries) {
            UserDefaults.standard.set(encoded, forKey: "diaryEntries")
        }
    }

 
    private func loadDiaryEntries() {
        if let data = UserDefaults.standard.data(forKey: "diaryEntries") {
            do {
                diaryEntries = try JSONDecoder().decode([DiaryEntry].self, from: data)
                print("Loaded diary entries: \(diaryEntries)")
            } catch {
                print("Failed to decode diary entries: \(error)")
                diaryEntries = []
            }
        }
    }


    private func binding(for entry: DiaryEntry) -> Binding<DiaryEntry> {
        guard let index = diaryEntries.firstIndex(where: { $0.id == entry.id }) else {
            fatalError("Entry not found")
        }
        return $diaryEntries[index]
    }

    // extract
    private func extractKeywords(from content: String, count: Int) -> String {
        let tagger = NLTagger(tagSchemes: [.lexicalClass])
        tagger.string = content
        var keywords: [String] = []
        let options: NLTagger.Options = [.omitWhitespace, .omitPunctuation]
        
        
        tagger.enumerateTags(in: content.startIndex..<content.endIndex, unit: .word, scheme: .lexicalClass, options: options) { tag, range in
            if let tag = tag, tag == .noun {
                keywords.append(String(content[range]))
                if keywords.count >= count {
                    return false //
                }
            }
            return true
        }
        
        
        if keywords.count < count {
            let words = content.components(separatedBy: .whitespacesAndNewlines).filter { !$0.isEmpty }
            for word in words.prefix(count - keywords.count) {
                keywords.append(word)
            }
        }
        
        return keywords.joined(separator: " ")
    }
}
