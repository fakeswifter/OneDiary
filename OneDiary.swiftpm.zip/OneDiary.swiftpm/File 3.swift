//
//  File 3.swift
//
//
//  Created on 2025/1/25.
//

import SwiftUI

struct TaskView: View {
    @Binding var tasks: [Task]
    
    var body: some View {
        
        NavigationView {
            VStack {
               
                Text(currentMonthString())
                                    .font(.title)
                                    .fontWeight(.semibold)
                                    .padding(.vertical, 10)
                
                
                
                
                List {
                    ForEach($tasks) { $task in
                        TaskRow(task: $task, saveTasks: saveTasks)
                    }
                }
                
            }
            .navigationTitle("Tasks")
            .onAppear {
                loadTasks()
            }
        }
    }
    
    private func currentMonthString() -> String {
        let date = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: date)
    }


    // UserDefaults
    private func saveTasks() {
        if let encoded = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }

    
    private func loadTasks() {
        if let data = UserDefaults.standard.data(forKey: "tasks") {
            do {
                tasks = try JSONDecoder().decode([Task].self, from: data)
            } catch {
                print("Failed to decode tasks: \(error)")
                tasks = defaultTasks()
            }
        } else {
            tasks = defaultTasks()
        }
    }


   
    private func defaultTasks() -> [Task] {
        let totalDays = Calendar.current.range(of: .day, in: .month, for: Date())?.count ?? 31
        let defaultTask = Task(title: "Write Everyday", description: "Recording your day", totalDays: totalDays)
        print("Default task created: \(defaultTask)")
        return [defaultTask]
    }
    
    func incrementProgress() {
        guard !tasks.isEmpty else { return }
        tasks[0].completedDays += 1
        if tasks[0].completedDays >= tasks[0].totalDays {
            tasks[0].isCompleted = true
        }
        saveTasks()
    }
}


struct TaskRow: View {
    @Binding var task: Task
    var saveTasks: () -> Void

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(task.title)
                    .font(.headline)
                Text(task.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }

            Spacer()

            
            Text(task.progress)
                .foregroundColor(.secondary)

            Button(action: {
                if task.completedDays < task.totalDays {
                    task.completedDays += 1
                    if task.completedDays == task.totalDays {
                        task.isCompleted = true
                    }
                    
                    saveTasks()
                }
            }) {
                Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                    .foregroundColor(task.isCompleted ? .green : .gray)
            }
        }
    }
}

