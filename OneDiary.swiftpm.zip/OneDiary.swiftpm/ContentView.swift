import SwiftUI


struct ContentView: View {
    @State private var diaryEntries: [DiaryEntry] = []
    @State private var tasks: [Task] = []
    @State private var showGuide: Bool = true
    
    var body: some View {
        if showGuide {
            GuideView(onDismiss: {
                showGuide = false
            })
        } else {
            TabView {
                DiaryView(diaryEntries: $diaryEntries, incrementProgress: incrementTaskProgress)
                    .tabItem {
                        Label("New Entry", systemImage: "plus.circle.fill")
                    }
                
                DiaryListView(diaryEntries: $diaryEntries)
                    .tabItem {
                        Label("Diary List", systemImage: "list.bullet")
                    }
                
                TaskView(tasks: $tasks)
                    .tabItem {
                        Label("Tasks", systemImage: "checkmark.circle.fill")
                    }
            }
            .onAppear {
                loadDiaryEntries()
                loadTasks()
            }
            if showGuide {
                GuideView(onDismiss: {
                    showGuide = false
                })
            }
        }
    }
    // task progress
    private func incrementTaskProgress() {
        guard !tasks.isEmpty else { return }
        tasks[0].completedDays += 1
        if tasks[0].completedDays >= tasks[0].totalDays {
            tasks[0].isCompleted = true
        }
        saveTasks()
    }

    // load
    private func loadDiaryEntries() {
        if let data = UserDefaults.standard.data(forKey: "diaryEntries") {
            do {
                let loadedEntries = try JSONDecoder().decode([DiaryEntry].self, from: data)
                diaryEntries = loadedEntries
            } catch {
                print("Failed to decode diary entries: \(error)")
            }
        }
    }

    // UserDefaults
    private func saveTasks() {
        if let encoded = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: "tasks")
        }
    }


    private func loadTasks() {
        if let data = UserDefaults.standard.data(forKey: "tasks") {
            do {
                tasks = try JSONDecoder().decode([Task].self, from: data)
            } catch {
                print("Failed to decode tasks: \(error)")
                tasks = defaultTasks()
            }
        } else {
            tasks = defaultTasks()
        }
    }

    // default tasks demo
    private func defaultTasks() -> [Task] {
        let totalDays = Calendar.current.range(of: .day, in: .month, for: Date())?.count ?? 31
        return [Task(title: "Write Everyday", description: "Recording your day", totalDays: totalDays)]
    }
}





struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
