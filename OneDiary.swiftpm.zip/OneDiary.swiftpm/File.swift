//
//  File.swift
//  OneDiary
//
//  Created on 2025/1/25.
//

import SwiftUI


struct DiaryEntry: Identifiable, Codable {
    let id: UUID
    let date: Date
    let content: String
    var photoPaths: [String]
    var mood: String?
    
    init(id: UUID = UUID(), date: Date = Date(), content: String, photoPaths: [String] = [], mood: String? = nil) {
        self.id = id
        self.date = date
        self.content = content
        self.photoPaths = photoPaths
        self.mood = mood
    }
}

// model
struct Task: Identifiable, Codable {
    let id: UUID
    let title: String
    let description: String
    let totalDays: Int
    var completedDays: Int
    let month: Date
    var isCompleted: Bool

    init(id: UUID = UUID(), title: String, description: String, totalDays: Int, completedDays: Int = 0, month: Date = Date(), isCompleted: Bool = false) {
        self.id = id
        self.title = title
        self.description = description
        self.totalDays = totalDays
        self.completedDays = completedDays
        self.month = month
        self.isCompleted = isCompleted
    }

    var progress: String {
        return "\(completedDays)/\(totalDays)"
    }
}


struct Quote: Identifiable, Codable {
    let id = UUID()
    let quoteText: String
    let quoteAuthor: String
    
    // return
    private enum CodingKeys: String, CodingKey {
        case quoteText = "quoteText"
        case quoteAuthor = "quoteAuthor"
    }
}
