//
//  GuideView.swift
//
//
//
//

import SwiftUI
import AVFoundation



struct GuideView: View {
    let onDismiss: () -> Void
    @State var guideStep: Int = 1
    @State private var isExpanded = false
    @State private var isZoomed = false
    
    
    
    var body: some View {
        ZStack {
            TabView(selection: $guideStep) {
                ScrollView {
                    VStack(alignment: .leading, spacing: 10) {
                        Group {
                            Text("Welcome to OneDiary ")
                                .font(.system(.largeTitle, design: .serif).bold())
                                .padding(.bottom)
                            Text("What is it?")
                                .font(.system(.title3, design: .rounded).bold())
                                .padding(.bottom)
                            Text("")
                                .font(.system(.body, design: .serif))
                            Text("In recent years, our lives have become more intelligent, almost all of us have used smart phones and experienced online services. My friends get anxious because they see the excellence of others online, but they don't see themselves shining in reality.")
                                .font(.system(.body, design: .serif))
                            Text("We're about to lose ourselves. We could not even feel the real mood. So I develop this demo to help people record their days in just a few words. I really want this to help people focus on themselves.")
                                .font(.system(.body, design: .serif))
                        }
                        Group {
                            Text("Dedication")
                                .font(.system(.title3, design: .rounded).bold())
                                .padding([.top, .bottom])
                            
                            //                            Text("")
                            //                                .font(.system(.body, design: .serif))
                            //                                .padding(.bottom)
                            
                            Text("Thanks to my friend John who gave me advices. Thanks to my teacher who brought the code course to me. Thanks to my family cuz they support me on it.")
                                .font(.system(.body, design: .serif))
                            Text("Lastly, I would like to show my gratitude to my favorite sociologist Biao Xiang.")
                                .font(.system(.body, design: .serif))
                            Image("Biao Xiang")
                                .resizable()
                                .frame(width: 150, height: 100)
                            //                            HStack{
                            //
                            //                                Button(action: {
                            //                                    audioManager.togglePlayPause()
                            //                                }) {
                            //                                    Image(systemName: audioManager.isPlaying ? "pause.circle.fill" : "music.note")
                            //                                        .resizable()
                            //                                        .frame(width: 20, height: 20)
                            //
                            //                                }
                            //                                .padding(.leading, 10)
                            //                                .padding(.top, -80)
                            //                                .foregroundColor(.brown)
                            //                            }
                            
                            Spacer(minLength: 100)
                        }
                    }.padding()
                }.tag(1)
                ScrollView{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Functions")
                            .font(.system(.title3, design: .rounded).bold())
                        
                        Text("Journal Mode")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("You may record your day in just a few words here , whether you are in a hurry or unwinding after work. ")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Image("1")
                            .resizable()
                            .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                            .frame(width: 250, height: 250 )
                        //                        .frame(width: isZoomed ? 200 : 200, height: isZoomed ? 270 : 250)
                        //                            .onTapGesture {
                        //                                            withAnimation {
                        //                                                isZoomed.toggle()
                        //                                            }
                        //                                        }
                        Text("Q & A Mode")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("According to a survey from THU shows that people experience more positive emotions when they interact with a computer, therefore, you may contact with AI here. ")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Image("2")
                            .resizable()
//                            .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                            .frame(width: 250, height: 250 )
                        
                        Text("Diary List")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("Here's your diary list. Every entry summarizes what you have recorded and your mood. Your mood could be chosen in the detail view and you could add some photos.")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Image("3")
                            .resizable()
                            .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                            .frame(width: 250, height: 250 )
                        
                        Text("Task")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("I add task to remind people to record their days. It can show your progress automatically.")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Image("4")
                            .resizable()
                            .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                            .frame(width: 250, height: 250 )
                    }
                }
                .padding()
                .tag(2)
                ScrollView{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Features")
                            .font(.system(.title3, design: .rounded).bold())
                        Text("Two Modes")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("When you're mad, you may talk to AI to help you calm down. When you're puzzled, you may ask for its help. At other times, don't forget to record your day! ")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        HStack{
                            Image("5")
                                .resizable()
                                .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                                .frame(width: 170, height: 170 )
                            Image("6")
                                .resizable()
                                .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                                .frame(width: 170, height: 170 )
                        }
                        
                        Text("Humanized and Entertaining")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("When you're mad for 2 days, it would like you to calm down, when you feel upset for 2 days, it would like you chin up, therefore, be positive!")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Text("Everyday is going to be a great day! I add the daily sentence to make the record an interesting thing.")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        HStack{
                            Image("7")
                                .resizable()
                                .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                                .frame(width: 170, height: 170 )
                            Image("8")
                                .resizable()
                                .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                                .frame(width: 170, height: 170 )
                        }
                        Image("9")
                            .resizable()
                            .aspectRatio(contentMode: isZoomed ? .fill : .fit)
                            .frame(width: 170, height: 170 )
                    }
            }
                
                .padding()
                .tag(3)
                ScrollView{
                    VStack(alignment: .leading, spacing: 10){
                        Text("Future work")
                            .font(.system(.title3, design: .rounded).bold())
                        Text("Tasks")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("Frankly, the reason I add the task in it is to make people realize that they need to connect with their surroundings. We need more connection with our friends, families and the nature. Through tasks, people could do it. I will add some tasks like recording your first Say Hello to a stranger.")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,50)
                        Text("More functions and UI")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                            .padding(.top,30)
                        Text("I will come up with more ideas to make this experience more interesting by more functions. And I will optimize the user interface.")
                            .font(.system(.subheadline, design: .serif))
                            .padding(.top,30)
                        
                        Text("Quotation")
                            .font(.system(.title3, design: .rounded).bold())
                            .padding(.top,30)
                        Text("1 Tang, L., Yuan, P., & Zhang, D. (2023). Emotional Experience during Human-Computer Interaction: A Survey. International Journal of Human–Computer Interaction, 40(8), 1845–1855. https://doi.org/10.1080/10447318.2023.2259710")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("2 AI communication uses OpenAI API https://platform.openai.com/docs/overview")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                        Text("3 Daily sentences uses Forismatic API https://api.forismatic.com/api/1.0/?method=getQuote&format=json&lang=en")
                            .font(.system(.body, design: .serif))
                            .fontWeight(.semibold)
                    }
                }
                
                .padding()
                .tag(4)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
            // button
            VStack {
                Spacer()
                HStack {
                    Button {
                        withAnimation {
                            if guideStep == 4 {
                                //                                router = .mainContent
                                onDismiss()
                            } else {
                                guideStep += 1
                            }
                            
                        }
                    } label: {
                        if guideStep == 4 {
                            Text("Finish Guide")
                            
                        } else {
                            Text("Continue")
                               
                        }
                    }
                    .padding()
                    .foregroundColor(.white)
                    .background(.brown)
                    .opacity(0.8)
                    .clipShape(RoundedRectangle(cornerRadius: 15))
                }.padding([.bottom], 50)
            }
        }
    }
}
 

struct GuideView_Previews: PreviewProvider {
    static var previews: some View {
        GuideView(onDismiss: {})
    }
}


